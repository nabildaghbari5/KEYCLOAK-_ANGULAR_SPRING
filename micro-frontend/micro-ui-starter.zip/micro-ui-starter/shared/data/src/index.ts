export * from './lib/data-access/data-access.component';
